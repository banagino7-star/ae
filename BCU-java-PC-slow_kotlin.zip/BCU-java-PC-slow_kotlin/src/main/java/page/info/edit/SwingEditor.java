package page.info.edit;

import common.CommonStatic;
import common.pack.Context.ErrType;
import common.pack.Identifier;
import common.pack.IndexContainer;
import common.util.Data;
import common.util.lang.Editors;
import common.util.lang.Editors.EditControl;
import common.util.lang.Editors.Editor;
import common.util.lang.Editors.EditorGroup;
import common.util.lang.Editors.EditorSupplier;
import common.util.lang.Formatter;
import common.util.lang.LocaleCenter;
import common.util.lang.ProcLang;
import common.util.pack.Background;
import common.util.stage.Music;
import common.util.unit.EneRand;
import page.*;
import utilpc.UtilPC;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.util.function.Consumer;

public abstract class SwingEditor extends Editor {

	public static class BoolEditor extends SwingEditor {

		public final JTG input;

		public BoolEditor(EditorGroup eg, Editors.EdiField field, String f, boolean edit) {
			super(eg, field, f, edit);
			input = new JTG(ProcLang.get().get(eg.proc).get(f));
			input.setLnr(this::edit);
		}

		@Override
		public void setVisible(boolean res) {
			input.setVisible(res);
		}

		@Override
		public boolean isInvisible() {
			return !input.isVisible();
		}

		@Override
		public void resize(int x, int y, int x0, int y0, int w0, int h0) {
			Page.set(input, x, y, x0, y0, w0, h0);
		}

		@Override
		public void setData() {
			field.setData(par.obj);
			input.setSelected(field.obj != null && field.getBoolean());
			input.setEnabled(edit && field.obj != null);
		}

		@Override
		protected void add(Consumer<JComponent> con) {
			con.accept(input);
		}

		private void edit(ActionEvent fe) {
			field.set(input.isSelected());
			update();
		}

	}

	public static class EditCtrl implements EditorSupplier {
		public interface Supplier {
			SupPage<Background> getBGSup(IdEditor<Background> edi);
			SupPage<Music> getMusicSup(IdEditor<Music> edi);
			SupPage<?> getEntitySup(IdEditor<?> edi);
			SupPage<?> getUnitSup(IdEditor<?> edi);
		}

		private final boolean isEnemy;
		private final Supplier table;

		public EditCtrl(boolean isEnemy, EntityEditPage table) {
			this.isEnemy = isEnemy;
			this.table = table;
		}

		@Override
		public Editor getEditor(EditControl<?> ctrl, EditorGroup group, String f, boolean edit) {
			try {
				Editors.EdiField field = ctrl.getField(f);
				Class<?> fc = field.getType();
				if (fc == int.class) {
					return new IntEditor(group, field, f, edit);
				}
				if (fc == boolean.class)
					return new BoolEditor(group, field, f, edit);
				if (fc == Identifier.class) {
                    switch (group.proc) {
                        case "THEME":
                            if (f.equals("id"))
                                return new IdEditor<>(group, field, f, table::getBGSup, edit);
                            else
                                return new IdEditor<>(group, field, f, table::getMusicSup, edit);
                        case "SUMMON":
                            return new IdEditor<>(group, field, f, table::getEntitySup, edit);
                        case "SPIRIT":
                            return new IdEditor<>(group, field, f, table::getUnitSup, edit);
                    }
				}
				if (fc.isEnum())
					return new EnumEditor(group, field, f, edit);
				throw new Exception("unexpected class " + fc);
			} catch (Exception e) {
				CommonStatic.ctx.noticeErr(e, ErrType.ERROR, "failed to generate editor");
			}
			return null;
		}

		@Override
		public void setEditorVisibility(Editor e, boolean b) {
			SwingEditor edi = (SwingEditor) e;
			edi.setVisible(b);
		}

		@Override
		public boolean EditorVisible(Editor e) {
			SwingEditor edi = (SwingEditor) e;
			return !edi.isInvisible();
		}

		@Override
		public boolean isEnemy() {
			return isEnemy;
		}

	}

	public static class IdEditor<T extends IndexContainer.Indexable<?, T>> extends SwingEditor {

		private final PageSup<T> page;

		public final JBTN input;
		public final JL jl;

		public IdEditor(EditorGroup par, Editors.EdiField field, String f, PageSup<T> page, boolean edit) {
			super(par, field, f, edit);
			this.page = page;
			input = new JBTN(ProcLang.get().get(par.proc).get(f));
			jl = new JL("");
			input.setLnr(this::edit);
		}

		public final void callback(Identifier<T> id) {
			field.set(id);
			update();
		}

		@Override
		public void setVisible(boolean res) {
			input.setVisible(res);
			jl.setVisible(res);
		}

		@Override
		public boolean isInvisible() {
			return !input.isVisible();
		}

		@Override
		public void resize(int x, int y, int x0, int y0, int w0, int h0) {
			Page.set(input, x, y, x0, y0, 150, h0);
			Page.set(jl, x, y, x0 + 150, y0, w0 - 150, h0);
		}

		@Override
		protected void add(Consumer<JComponent> con) {
			con.accept(input);
			con.accept(jl);
		}

		@Override
		protected void setData() {
			field.setData(par.obj);

			Object obj = field.get();

			if(obj instanceof Identifier<?>)
				if(((Identifier<?>) obj).cls == EneRand.class)
					jl.setText(field.get() + " [Random]");
				else
					jl.setText(String.valueOf(field.get()));
			else
				jl.setText(String.valueOf(field.get()));

			input.setEnabled(edit && field.obj != null);
		}

		private void edit(ActionEvent fe) {
			MainFrame.changePanel(page.get(this).getThisPage());
		}

	}

	public static class IntEditor extends SwingEditor {

		public final JL label;
		public final JTF input = new JTF();

		public IntEditor(EditorGroup eg, Editors.EdiField field, String f, boolean edit) {
			super(eg, field, f, edit);
			label = new JL(ProcLang.get().get(eg.proc).get(f));
			input.setLnr(this::edit);
		}

		@Override
		public void setVisible(boolean res) {
			label.setVisible(res);
			input.setVisible(res);
		}

		@Override
		public boolean isInvisible() {
			return !label.isVisible();
		}

		@Override
		public void resize(int x, int y, int x0, int y0, int w0, int h0) {
			Page.set(label, x, y, x0, y0, 150, h0);
			Page.set(input, x, y, x0 + 150, y0, w0 - 150, h0);
		}

		@Override
		public void setData() {
			field.setData(par.obj);
			if (field.obj == null)
				input.setText("");
			else
				input.setText(String.valueOf(field.getInt()));
			input.setEnabled(edit && field.obj != null);
		}

		@Override
		protected void add(Consumer<JComponent> con) {
			con.accept(label);
			con.accept(input);
		}

		@SuppressWarnings("ConstantConditions")
		private void edit(FocusEvent fe) {
			field.setInt(Data.ignore(() -> CommonStatic.parseIntN(input.getText())));
			update();
		}

	}

	public static class EnumEditor extends SwingEditor {
		public final JBTN input;
		public final LocaleCenter.Binder binder;

		public EnumEditor(EditorGroup eg, Editors.EdiField field, String f, boolean edit) {
			super(eg, field, f, edit);
			binder = ProcLang.get().get(par.proc).get(name);
			input = new JBTN(binder);
			input.setLnr(this::edit);
		}

		@Override
		public void setVisible(boolean res) {
			input.setVisible(res);
		}

		@Override
		public boolean isInvisible() {
			return !input.isVisible();
		}

		@Override
		public void resize(int x, int y, int x0, int y0, int w0, int h0) {
			Page.set(input, x, y, x0, y0, 350, h0);
		}

		@Override
		protected void add(Consumer<JComponent> con) {
			con.accept(input);
		}

		@Override
		protected void setData() {
			field.setData(par.obj);
			Object obj = field.get();
			binder.setNameValue(binder.getNameValue().split(":")[0] + ": " + (obj != null ? ((Enum<?>) obj).ordinal() : "?"));

			input.setEnabled(edit && field.obj != null);
			input.getLSC().update();
		}

		private void edit(ActionEvent fe) {
			Object obj = field.get();
			if (obj != null) {
				Enum<?> val = (Enum<?>) obj;
				Enum<?>[] enums = val.getDeclaringClass().getEnumConstants();
				Enum<?> ans = enums[(val.ordinal() + 1) % enums.length];
				field.set(ans);
			}
			update();
		}
	}

	public interface PageSup<T extends IndexContainer.Indexable<?, T>> {

		SupPage<T> get(IdEditor<T> editor);

	}

	public static class SwingEG extends EditorGroup {

		public final JL jlm;

		public SwingEG(int ind, boolean edit, Runnable cb, Formatter.Context ctx) {
			super(Data.Proc.getName(ind), edit, cb);
			jlm = new JL(getItem(ctx));
			jlm.setIcon(UtilPC.getScaledIcon(UtilPC.createIcon(1, ind), 40, 40));
		}

		@Override
		public void setData(Object obj) {
			super.setData(obj);
			jlm.getLSC().update();
		}
	}

	public boolean edit;

	public SwingEditor(EditorGroup par, Editors.EdiField field, String f, boolean edit) {
		super(par, field, f);
		this.edit = edit;
	}

	public abstract void setVisible(boolean res);

	public abstract boolean isInvisible();

	public abstract void resize(int x, int y, int x0, int y0, int w0, int h0);

	protected abstract void add(Consumer<JComponent> con);

}
